let streak=0;
function showTab(id){
  document.querySelectorAll('.tab').forEach(t=>t.style.display='none');
  document.getElementById(id).style.display='block';
}
// Journey
let journeyHTML='<h2>Journey Map</h2><div class="map">';
for(let w=1;w<=12;w++){journeyHTML+=`<div class="node locked">W${w}</div>`;}
journeyHTML+='</div><p>Tap a week to unlock lessons.</p>';
document.getElementById('journey').innerHTML=journeyHTML;
// Streak
document.getElementById('streak').innerHTML='<h2>Daily Free Streak</h2><p>20 basic exercises available today.<br>🔥 Keep your streak alive!</p>';
// Books
document.getElementById('books').innerHTML='<h2>Books</h2>'+
  '<div class="book"><h3>El Cuervo</h3><button>Read PDF</button><button>Buy Physical</button><button>Immersive</button></div>'+
  '<div class="book"><h3>Pride & Prejudice</h3><button>$2</button></div>'+
  '<div class="book"><h3>Dracula</h3><button>$2</button></div>';
// Corrections demo
document.getElementById('corrections').innerHTML='<h2>Corrections & Q&A</h2>'+
  '<div class="card"><b>Homework:</b> Pronunciation exercise<br>Status: Corrected ✅<br>Feedback: Practice the TH sound.</div>'+
  '<div class="card"><b>Q:</b> How do you say estás loco in English?<br><b>A:</b> You are crazy!</div>';
// Profile
document.getElementById('profile').innerHTML='<h2>Profile</h2><p>Name: Student</p>';